function[norma]=nor(A,p)
X=norm(A,p)
end