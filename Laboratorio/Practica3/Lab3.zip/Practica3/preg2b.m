%Ejercio 2 - b
x=5.01:.01:15;
y = errork(x);
plot(x,y,'r*-')