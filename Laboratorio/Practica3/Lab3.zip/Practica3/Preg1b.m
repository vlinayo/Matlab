%Preg1b
%Para calcular AxA^-1 se procede a escribir en matlab lo siguiente:
%matriz(n) * inv(matriz(n)), para n=1,2,3,....n. podemos apreciar que mientras mayor es nuestro n la forma de la matriz identidad se pierde, 
%esto se debe a que el calculo de la m�quina no es exacto, y tammbien debido a lo que conocemos como errores de la m�quina.

%Para calcular || A* A^-1 -I||inf
%Procedo a crear la matriz A= matriz(25)
%y c= A* inv(A)- eye(25)
%y procedemos a calcular la norma: norm(c,inf)
