%Veronica Li�ayo
%Carnet: 08-10615
%funci�n que calcula la primera soluci�n de la ra�z (2), es decir, la
%obtenida de realizar la suma en el denominador.
function[y1]=raiz2a(a,b,c)
y1= (-2*c)/(b + sqrt(b^2 - 4*a*c));
end