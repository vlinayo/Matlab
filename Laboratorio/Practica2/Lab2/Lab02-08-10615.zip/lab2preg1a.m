%PREGUNTA 1.a
%Demostracion:
%Igualando Ambas Ecuaciones.
% (-b +- sqrt(b^2 - 4*a*c)/(2*a))= (-2*c)/(b +- sqrt(b^2 - 4*a*c))
% (-b +- sqrt(b^2 - 4*a*c)*(b +- sqrt(b^2 - 4*a*c)= (-2*c)*(2*a)
% (-b)^2 + b^2 -4*a*c= -4*a*c
% -4*a*c= -4*a*c
% a*c=a*c
% a=a

% Entonces podemos ver que ambas son iguales.
