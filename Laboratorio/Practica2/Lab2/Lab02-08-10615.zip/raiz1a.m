%Veronica Li�ayo
%Carnet: 08-10615
%funci�n que calcula la primera soluci�n de la ra�z (1), es decir, la obtenida de realizar la suma en el numerador.

function[x1]=raiz1a(a,b,c)
x1=(-b + sqrt(b^2 - 4*a*c))/(2*a);
end
