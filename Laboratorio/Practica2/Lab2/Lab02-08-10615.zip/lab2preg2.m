%Veronica Li�ayo
%Carnet: 08-10615
% Script que permite graficar la funci�n f(x) de la pregunta 2. para x en
% el intervalo [-3,3].

format long
X=linspace(-3,3);
Y=fun(X);
plot(X,Y);
